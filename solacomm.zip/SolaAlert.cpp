#include "StdAfx.h"
#include "SolaComm.h"
#include "SolaAlert.h"

CSolaAlert::CSolaAlert()
{
	m_lpSolaAlert = NULL;
	m_cbSize = 0;
}

CSolaAlert::~CSolaAlert(void)
{
}
